package pl.itemshop;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.List;

/** Komenda rejestrowana dynamicznie, zeby nazwa/aliasy byly z configu. */
public class DynCommand extends Command {
    private final TabExecutor handler;

    public DynCommand(String name, List<String> aliases, TabExecutor handler) {
        super(name);
        setAliases(aliases);
        this.handler = handler;
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        return handler.onCommand(sender, this, label, args);
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String alias, String[] args) {
        List<String> r = handler.onTabComplete(sender, this, alias, args);
        return r == null ? List.of() : r;
    }
}
