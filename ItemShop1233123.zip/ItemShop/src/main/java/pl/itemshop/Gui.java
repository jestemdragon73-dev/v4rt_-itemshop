package pl.itemshop;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Gui {
    private final ItemShopPlugin pl;
    private final PakietManager mgr;

    public Gui(ItemShopPlugin pl, PakietManager mgr) {
        this.pl = pl;
        this.mgr = mgr;
    }

    public void otworz(Player p) {
        FileConfiguration c = pl.getConfig();
        List<PakietManager.Owned> list = mgr.lista(p.getUniqueId());
        if (list.isEmpty()) {
            pl.send(p, "brak-pakietow");
            return;
        }
        int rzedy = Math.max(1, Math.min(6, c.getInt("gui.rzedy", 3)));
        OdbierzHolder h = new OdbierzHolder();
        Inventory inv = Bukkit.createInventory(h, rzedy * 9, Text.c(c.getString("gui.tytul", "&7Twoje pakiety")));
        h.inv = inv;
        int slot = 0;
        for (PakietManager.Owned o : list) {
            if (slot >= rzedy * 9) break;
            Pakiet pk = mgr.get(o.pakiet());
            if (pk == null) continue;
            inv.setItem(slot, ikona(pk, o));
            h.sloty.put(slot, o.uid());
            slot++;
        }
        p.openInventory(inv);
    }

    public void otworzEdytor(Player p, Pakiet pk) {
        EditorHolder h = new EditorHolder(pk.id);
        Inventory inv = Bukkit.createInventory(h, 54, Text.c("&8Edytor pakietu: " + pk.id));
        h.inv = inv;
        for (int i = 0; i < pk.itemy.size() && i < 54; i++) inv.setItem(i, pk.itemy.get(i).clone());
        p.openInventory(inv);
    }

    private ItemStack ikona(Pakiet pk, PakietManager.Owned o) {
        FileConfiguration c = pl.getConfig();
        ItemStack is = new ItemStack(pk.ikona);
        ItemMeta m = is.getItemMeta();
        m.displayName(Text.c(c.getString("gui.nazwa-pakietu", "&a%nazwa%").replace("%nazwa%", pk.nazwa)));
        List<Component> lore = new ArrayList<>();
        for (String line : c.getStringList("gui.lore")) {
            if (line.equals("%zawartosc%")) {
                for (String z : opis(pk)) lore.add(Text.c(z));
                continue;
            }
            lore.add(Text.c(line
                    .replace("%data%", mgr.data(o.czas()))
                    .replace("%od%", o.od())
                    .replace("%nazwa%", pk.nazwa)
                    .replace("%id%", pk.id)));
        }
        m.lore(lore);
        is.setItemMeta(m);
        return is;
    }

    public List<String> opis(Pakiet pk) {
        FileConfiguration c = pl.getConfig();
        List<String> out = new ArrayList<>();
        for (ItemStack it : pk.itemy) {
            out.add(c.getString("gui.format-itemu", " &8- &f%ilosc%x &e%nazwa%")
                    .replace("%ilosc%", String.valueOf(it.getAmount()))
                    .replace("%nazwa%", Text.nazwaItemu(it)));
        }
        for (String r : pk.rangi) {
            String[] t = r.split(";", 2);
            if (t.length == 2) {
                out.add(c.getString("gui.format-rangi-czasowej", " &8- &fRanga: &d%ranga% &7(%czas%)")
                        .replace("%ranga%", t[0]).replace("%czas%", t[1]));
            } else {
                out.add(c.getString("gui.format-rangi", " &8- &fRanga: &d%ranga%").replace("%ranga%", t[0]));
            }
        }
        for (Map.Entry<String, Integer> e : pk.klucze.entrySet()) {
            out.add(c.getString("gui.format-klucza", " &8- &fKlucz: &6%ilosc%x %klucz%")
                    .replace("%ilosc%", String.valueOf(e.getValue()))
                    .replace("%klucz%", e.getKey()));
        }
        return out;
    }
}

class OdbierzHolder implements InventoryHolder {
    final Map<Integer, String> sloty = new HashMap<>();
    Inventory inv;

    @Override
    public Inventory getInventory() {
        return inv;
    }
}

class EditorHolder implements InventoryHolder {
    final String id;
    Inventory inv;

    EditorHolder(String id) {
        this.id = id;
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
