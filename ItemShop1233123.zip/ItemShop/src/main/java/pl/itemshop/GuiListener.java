package pl.itemshop;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class GuiListener implements Listener {
    private final ItemShopPlugin pl;
    private final PakietManager mgr;
    private final Gui gui;

    public GuiListener(ItemShopPlugin pl, PakietManager mgr, Gui gui) {
        this.pl = pl;
        this.mgr = mgr;
        this.gui = gui;
    }

    @EventHandler
    public void click(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof OdbierzHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != top) return;
        String uid = h.sloty.get(e.getSlot());
        if (uid == null) return;

        PakietManager.Owned o = mgr.lista(p.getUniqueId()).stream()
                .filter(x -> x.uid().equals(uid)).findFirst().orElse(null);
        if (o == null) {
            Bukkit.getScheduler().runTask(pl, () -> gui.otworz(p));
            return;
        }
        if (mgr.odbierz(p, o)) {
            Bukkit.getScheduler().runTask(pl, () -> {
                if (mgr.lista(p.getUniqueId()).isEmpty()) p.closeInventory();
                else gui.otworz(p);
            });
        }
    }

    @EventHandler
    public void drag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof OdbierzHolder) e.setCancelled(true);
    }

    @EventHandler
    public void close(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof EditorHolder h)) return;
        Pakiet pk = mgr.get(h.id);
        if (pk == null) return;
        List<ItemStack> itemy = new ArrayList<>();
        for (ItemStack it : e.getInventory().getContents()) {
            if (it != null && !it.getType().isAir()) itemy.add(it.clone());
        }
        pk.itemy = itemy;
        mgr.zapiszPakiety();
        pl.send(e.getPlayer(), "zapisano-pakiet", "id", h.id, "ilosc", String.valueOf(itemy.size()));
    }

    @EventHandler
    public void join(PlayerJoinEvent e) {
        if (!pl.getConfig().getBoolean("powiadomienie.przy-wejsciu", true)) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(pl, () -> {
            int n = mgr.lista(p.getUniqueId()).size();
            if (n > 0 && p.isOnline()) pl.send(p, "masz-pakiety", "ilosc", String.valueOf(n));
        }, 40L);
    }
}
