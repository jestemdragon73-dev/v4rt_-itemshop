package pl.itemshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.*;

public class ItemShopCommand implements TabExecutor {
    private final ItemShopPlugin pl;
    private final PakietManager mgr;
    private final Gui gui;

    public ItemShopCommand(ItemShopPlugin pl, PakietManager mgr, Gui gui) {
        this.pl = pl;
        this.mgr = mgr;
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("przekaz")) {
            przekaz(s, a);
            return true;
        }
        if (!s.hasPermission("itemshop.admin")) {
            pl.send(s, "brak-uprawnien");
            return true;
        }
        if (a.length == 0) {
            pomoc(s);
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "pakiet" -> pakiet(s, a);
            case "keyall" -> keyall(s, a);
            case "reload" -> {
                pl.przeladuj();
                pl.send(s, "przeladowano");
            }
            default -> pomoc(s);
        }
        return true;
    }

    private void pomoc(CommandSender s) {
        for (String l : pl.getConfig().getStringList("pomoc")) s.sendMessage(Text.c(l));
    }

    private void pakiet(CommandSender s, String[] a) {
        if (a.length < 2) {
            pomoc(s);
            return;
        }
        switch (a[1].toLowerCase()) {
            case "create" -> {
                if (a.length < 3) { pomoc(s); return; }
                String id = a[2].toLowerCase();
                if (!id.matches("[a-z0-9_\\-]+")) { pl.send(s, "nie-poprawne-id"); return; }
                if (mgr.get(id) != null) { pl.send(s, "pakiet-istnieje", "id", id); return; }
                String nazwa = a.length > 3 ? String.join(" ", Arrays.copyOfRange(a, 3, a.length)) : id;
                Pakiet pk = mgr.utworz(id, nazwa);
                pl.send(s, "utworzono", "id", id);
                if (s instanceof Player p) gui.otworzEdytor(p, pk);
            }
            case "delete" -> {
                if (a.length < 3) { pomoc(s); return; }
                if (mgr.usun(a[2])) pl.send(s, "usunieto", "id", a[2].toLowerCase());
                else pl.send(s, "pakiet-nie-istnieje", "id", a[2]);
            }
            case "daj" -> daj(s, a);
            case "edytuj" -> edytuj(s, a);
            case "lista" -> {
                for (Pakiet pk : mgr.wszystkie()) {
                    s.sendMessage(Text.c("&b" + pk.id + " &7- &f" + pk.nazwa
                            + " &8(itemy: " + pk.itemy.size() + ", rangi: " + pk.rangi.size()
                            + ", klucze: " + pk.klucze.size() + ", komendy: " + pk.komendy.size() + ")"));
                }
            }
            case "historia" -> {
                String filtr = a.length > 2 ? a[2] : null;
                for (String h : mgr.historia(filtr)) s.sendMessage(Text.c("&7" + h));
            }
            default -> pomoc(s);
        }
    }

    private void daj(CommandSender s, String[] a) {
        if (a.length < 4) { pomoc(s); return; }
        Pakiet pk = mgr.get(a[3]);
        if (pk == null) { pl.send(s, "pakiet-nie-istnieje", "id", a[3]); return; }
        int ile = 1;
        if (a.length > 4) {
            try { ile = Math.max(1, Math.min(100, Integer.parseInt(a[4]))); }
            catch (NumberFormatException e) { pl.send(s, "zla-liczba"); return; }
        }
        Player online = Bukkit.getPlayerExact(a[2]);
        OfflinePlayer op = online != null ? online : Bukkit.getOfflinePlayer(a[2]);
        if (online == null && !op.hasPlayedBefore()) { pl.send(s, "gracz-offline", "gracz", a[2]); return; }
        String od = s instanceof Player ? s.getName() : "Konsola";
        String nazwa = op.getName() != null ? op.getName() : a[2];
        for (int i = 0; i < ile; i++) mgr.daj(op.getUniqueId(), nazwa, pk, od);
        pl.send(s, "nadano", "pakiet", pk.id, "gracz", nazwa);
    }

    private void edytuj(CommandSender s, String[] a) {
        if (a.length < 4) { pomoc(s); return; }
        Pakiet pk = mgr.get(a[2]);
        if (pk == null) { pl.send(s, "pakiet-nie-istnieje", "id", a[2]); return; }
        String co = a[3].toLowerCase();
        switch (co) {
            case "items", "itemy" -> {
                if (s instanceof Player p) gui.otworzEdytor(p, pk);
                else pl.send(s, "tylko-gracz");
                return;
            }
            case "info" -> {
                s.sendMessage(Text.c("&bPakiet &f" + pk.id + " &7(" + pk.nazwa + ", ikona " + pk.ikona + ")"));
                for (String l : gui.opis(pk)) s.sendMessage(Text.c(l));
                int i = 1;
                for (String k : pk.komendy) s.sendMessage(Text.c(" &8" + (i++) + ". &7/" + k));
                return;
            }
            case "nazwa" -> {
                if (a.length < 5) { pomoc(s); return; }
                pk.nazwa = String.join(" ", Arrays.copyOfRange(a, 4, a.length));
            }
            case "ikona" -> {
                if (a.length < 5) { pomoc(s); return; }
                Material m = Material.matchMaterial(a[4]);
                if (m == null || m.isAir()) { pl.send(s, "zly-material"); return; }
                pk.ikona = m;
            }
            case "komenda" -> {
                if (a.length < 5) { pomoc(s); return; }
                switch (a[4].toLowerCase()) {
                    case "dodaj" -> {
                        if (a.length < 6) { pomoc(s); return; }
                        String cmd = String.join(" ", Arrays.copyOfRange(a, 5, a.length));
                        pk.komendy.add(cmd.startsWith("/") ? cmd.substring(1) : cmd);
                    }
                    case "usun" -> {
                        try {
                            int n = Integer.parseInt(a[5]) - 1;
                            if (n < 0 || n >= pk.komendy.size()) { pl.send(s, "zla-liczba"); return; }
                            pk.komendy.remove(n);
                        } catch (RuntimeException e) { pl.send(s, "zla-liczba"); return; }
                    }
                    case "lista" -> {
                        int i = 1;
                        for (String k : pk.komendy) s.sendMessage(Text.c("&8" + (i++) + ". &7/" + k));
                        return;
                    }
                    default -> { pomoc(s); return; }
                }
            }
            case "ranga" -> {
                if (a.length < 6) { pomoc(s); return; }
                String ranga = a[5];
                if (a[4].equalsIgnoreCase("dodaj")) {
                    pk.rangi.add(a.length > 6 ? ranga + ";" + a[6] : ranga);
                } else if (a[4].equalsIgnoreCase("usun")) {
                    pk.rangi.removeIf(r -> r.split(";", 2)[0].equalsIgnoreCase(ranga));
                } else { pomoc(s); return; }
            }
            case "klucz" -> {
                if (a.length < 6) { pomoc(s); return; }
                String klucz = a[5];
                if (a[4].equalsIgnoreCase("dodaj")) {
                    int ile;
                    try { ile = a.length > 6 ? Integer.parseInt(a[6]) : 1; }
                    catch (NumberFormatException e) { pl.send(s, "zla-liczba"); return; }
                    pk.klucze.put(klucz, Math.max(1, ile));
                } else if (a[4].equalsIgnoreCase("usun")) {
                    pk.klucze.remove(klucz);
                } else { pomoc(s); return; }
            }
            default -> { pomoc(s); return; }
        }
        mgr.zapiszPakiety();
        pl.send(s, "zapisano-edycje", "id", pk.id);
    }

    private void keyall(CommandSender s, String[] a) {
        if (a.length < 4 || !a[1].equalsIgnoreCase("rozdaj")) { pomoc(s); return; }
        int ile;
        try { ile = Integer.parseInt(a[3]); } catch (NumberFormatException e) { pl.send(s, "zla-liczba"); return; }
        int n = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            mgr.dajKlucz(p, a[2], ile);
            n++;
        }
        pl.send(s, "keyall", "klucz", a[2], "ilosc", String.valueOf(ile), "gracze", String.valueOf(n));
    }

    private void przekaz(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { pl.send(s, "tylko-gracz"); return; }
        if (!pl.getConfig().getBoolean("przekazywanie", true)) { pl.send(p, "przekazywanie-wylaczone"); return; }
        if (!p.hasPermission("itemshop.przekaz")) { pl.send(p, "brak-uprawnien"); return; }
        if (a.length < 3) { pomoc(s); return; }
        Player cel = Bukkit.getPlayerExact(a[1]);
        if (cel == null || cel.equals(p)) { pl.send(p, "gracz-offline", "gracz", a[1]); return; }
        PakietManager.Owned o = mgr.lista(p.getUniqueId()).stream()
                .filter(x -> x.pakiet().equalsIgnoreCase(a[2])).findFirst().orElse(null);
        if (o == null) { pl.send(p, "nie-masz-pakietu", "id", a[2]); return; }
        Pakiet pk = mgr.get(o.pakiet());
        if (mgr.przekaz(p, cel, o)) {
            pl.send(p, "przekazano", "pakiet", pk != null ? pk.nazwa : o.pakiet(), "gracz", cel.getName());
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out = List.of("pakiet", "przekaz", "keyall", "reload");
        } else if (a[0].equalsIgnoreCase("przekaz")) {
            return filtr(a.length == 2 ? onlineNames() : ids(), a[a.length - 1]);
        } else if (a[0].equalsIgnoreCase("pakiet")) {
            String sub = a[1].toLowerCase();
            if (a.length == 2) out = List.of("create", "delete", "daj", "edytuj", "historia", "lista");
            else if (a.length == 3 && (sub.equals("delete") || sub.equals("edytuj"))) out = ids();
            else if (a.length == 3 && (sub.equals("daj") || sub.equals("historia"))) out = onlineNames();
            else if (a.length == 4 && sub.equals("daj")) out = ids();
            else if (a.length == 4 && sub.equals("edytuj")) out = List.of("items", "nazwa", "ikona", "komenda", "ranga", "klucz", "info");
            else if (a.length == 5 && sub.equals("edytuj")) {
                String co = a[3].toLowerCase();
                if (co.equals("komenda")) out = List.of("dodaj", "usun", "lista");
                else if (co.equals("ranga") || co.equals("klucz")) out = List.of("dodaj", "usun");
            }
        }
        return filtr(out, a[a.length - 1]);
    }

    private List<String> ids() {
        List<String> r = new ArrayList<>();
        for (Pakiet p : mgr.wszystkie()) r.add(p.id);
        return r;
    }

    private List<String> onlineNames() {
        List<String> r = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) r.add(p.getName());
        return r;
    }

    private List<String> filtr(List<String> in, String last) {
        List<String> r = new ArrayList<>();
        for (String x : in) if (x.toLowerCase().startsWith(last.toLowerCase())) r.add(x);
        return r;
    }
}
