package pl.itemshop;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class ItemShopPlugin extends JavaPlugin {
    private PakietManager manager;
    private Gui gui;
    private final List<DynCommand> dyn = new ArrayList<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new PakietManager(this);
        gui = new Gui(this, manager);
        getServer().getPluginManager().registerEvents(new GuiListener(this, manager, gui), this);
        rejestrujKomendy();
        getLogger().info("ItemShop v" + getPluginMeta().getVersion() + " | Autor: v4rt_ | Discord: dc.shulkermc.pl");
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.zapiszPakiety();
            manager.zapiszDane();
        }
        wyrejestruj();
    }

    public void przeladuj() {
        reloadConfig();
        manager.wczytaj();
        wyrejestruj();
        rejestrujKomendy();
        for (Player p : Bukkit.getOnlinePlayers()) p.updateCommands();
    }

    private void rejestrujKomendy() {
        CommandMap map = getServer().getCommandMap();
        DynCommand odbierz = new DynCommand(
                getConfig().getString("komenda-odbierz.nazwa", "odbierz").toLowerCase(),
                getConfig().getStringList("komenda-odbierz.aliasy"),
                new OdbierzCommand(this, manager, gui));
        DynCommand admin = new DynCommand(
                getConfig().getString("komenda-admin.nazwa", "itemshop").toLowerCase(),
                getConfig().getStringList("komenda-admin.aliasy"),
                new ItemShopCommand(this, manager, gui));
        for (DynCommand c : List.of(odbierz, admin)) {
            map.register("itemshop", c);
            dyn.add(c);
        }
    }

    private void wyrejestruj() {
        CommandMap map = getServer().getCommandMap();
        for (DynCommand c : dyn) {
            c.unregister(map);
            map.getKnownCommands().values().removeIf(v -> v == c);
        }
        dyn.clear();
    }

    public String komendaOdbierz() {
        return getConfig().getString("komenda-odbierz.nazwa", "odbierz");
    }

    public String raw(String key, String... kv) {
        String t = getConfig().getString("wiadomosci." + key, "&cBrak wiadomosci: " + key);
        for (int i = 0; i + 1 < kv.length; i += 2) t = t.replace("%" + kv[i] + "%", kv[i + 1]);
        return t.replace("%komenda%", komendaOdbierz());
    }

    public void send(CommandSender s, String key, String... kv) {
        s.sendMessage(Text.c(getConfig().getString("wiadomosci.prefix", "") + raw(key, kv)));
    }
}
