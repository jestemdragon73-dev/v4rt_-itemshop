package pl.itemshop;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

public class OdbierzCommand implements TabExecutor {
    private final ItemShopPlugin pl;
    private final PakietManager mgr;
    private final Gui gui;

    public OdbierzCommand(ItemShopPlugin pl, PakietManager mgr, Gui gui) {
        this.pl = pl;
        this.mgr = mgr;
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof Player p)) {
            pl.send(s, "tylko-gracz");
            return true;
        }
        String perm = pl.getConfig().getString("komenda-odbierz.uprawnienie", "");
        if (!perm.isEmpty() && !p.hasPermission(perm)) {
            pl.send(p, "brak-uprawnien");
            return true;
        }
        if (mgr.lista(p.getUniqueId()).isEmpty()) {
            pl.send(p, "brak-pakietow");
            return true;
        }
        if (a.length > 0 && a[0].equalsIgnoreCase("wszystko")) {
            mgr.odbierzWszystko(p);
            return true;
        }
        gui.otworz(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        return a.length == 1 ? List.of("wszystko") : List.of();
    }
}
