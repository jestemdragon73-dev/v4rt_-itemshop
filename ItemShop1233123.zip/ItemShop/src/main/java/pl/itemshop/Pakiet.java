package pl.itemshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Pakiet {
    public final String id;
    public String nazwa;
    public Material ikona = Material.CHEST;
    public List<ItemStack> itemy = new ArrayList<>();
    public List<String> komendy = new ArrayList<>();
    /** wpisy: "ranga" albo "ranga;czas" (np. "vip;30d") */
    public List<String> rangi = new ArrayList<>();
    public Map<String, Integer> klucze = new LinkedHashMap<>();

    public Pakiet(String id) {
        this.id = id;
        this.nazwa = id;
    }

    public static Pakiet wczytaj(String id, ConfigurationSection s) {
        Pakiet p = new Pakiet(id);
        p.nazwa = s.getString("nazwa", id);
        Material m = Material.matchMaterial(s.getString("ikona", "CHEST"));
        p.ikona = m == null ? Material.CHEST : m;
        List<?> items = s.getList("itemy");
        if (items != null) {
            for (Object o : items) {
                if (o instanceof ItemStack is) p.itemy.add(is);
            }
        }
        p.komendy.addAll(s.getStringList("komendy"));
        p.rangi.addAll(s.getStringList("rangi"));
        ConfigurationSection k = s.getConfigurationSection("klucze");
        if (k != null) {
            for (String n : k.getKeys(false)) p.klucze.put(n, k.getInt(n));
        }
        return p;
    }

    public void zapisz(ConfigurationSection s) {
        s.set("nazwa", nazwa);
        s.set("ikona", ikona.name());
        s.set("itemy", itemy);
        s.set("komendy", komendy);
        s.set("rangi", rangi);
        for (Map.Entry<String, Integer> e : klucze.entrySet()) {
            s.set("klucze." + e.getKey(), e.getValue());
        }
    }
}
