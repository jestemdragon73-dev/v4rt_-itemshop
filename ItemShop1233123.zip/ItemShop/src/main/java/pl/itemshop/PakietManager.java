package pl.itemshop;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class PakietManager {
    public record Owned(String uid, String pakiet, String od, long czas) {}

    private final ItemShopPlugin pl;
    private final File pakietyFile;
    private final File daneFile;
    private final Map<String, Pakiet> pakiety = new LinkedHashMap<>();
    private final Map<UUID, List<Owned>> gracze = new HashMap<>();
    private final List<String> historia = new ArrayList<>();

    public PakietManager(ItemShopPlugin pl) {
        this.pl = pl;
        pl.getDataFolder().mkdirs();
        this.pakietyFile = new File(pl.getDataFolder(), "pakiety.yml");
        this.daneFile = new File(pl.getDataFolder(), "dane.yml");
        wczytaj();
    }

    // ---------- wczytywanie / zapis ----------

    public void wczytaj() {
        pakiety.clear();
        gracze.clear();
        historia.clear();

        YamlConfiguration y = YamlConfiguration.loadConfiguration(pakietyFile);
        ConfigurationSection sec = y.getConfigurationSection("pakiety");
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(id);
                if (s != null) pakiety.put(id.toLowerCase(), Pakiet.wczytaj(id.toLowerCase(), s));
            }
        }

        YamlConfiguration d = YamlConfiguration.loadConfiguration(daneFile);
        ConfigurationSection gs = d.getConfigurationSection("gracze");
        if (gs != null) {
            for (String key : gs.getKeys(false)) {
                UUID u;
                try {
                    u = UUID.fromString(key);
                } catch (IllegalArgumentException e) {
                    continue;
                }
                List<Owned> list = new ArrayList<>();
                for (Map<?, ?> m : d.getMapList("gracze." + key)) {
                    try {
                        list.add(new Owned(
                                String.valueOf(m.get("uid")),
                                String.valueOf(m.get("pakiet")),
                                String.valueOf(m.get("od")),
                                Long.parseLong(String.valueOf(m.get("czas")))));
                    } catch (NumberFormatException ignored) {
                    }
                }
                gracze.put(u, list);
            }
        }
        historia.addAll(d.getStringList("historia"));
    }

    public void zapiszPakiety() {
        YamlConfiguration y = new YamlConfiguration();
        for (Pakiet p : pakiety.values()) p.zapisz(y.createSection("pakiety." + p.id));
        try {
            y.save(pakietyFile);
        } catch (IOException e) {
            pl.getLogger().warning("Nie mozna zapisac pakiety.yml: " + e.getMessage());
        }
    }

    public void zapiszDane() {
        YamlConfiguration d = new YamlConfiguration();
        for (Map.Entry<UUID, List<Owned>> e : gracze.entrySet()) {
            if (e.getValue().isEmpty()) continue;
            List<Map<String, Object>> list = new ArrayList<>();
            for (Owned o : e.getValue()) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("uid", o.uid());
                m.put("pakiet", o.pakiet());
                m.put("od", o.od());
                m.put("czas", o.czas());
                list.add(m);
            }
            d.set("gracze." + e.getKey(), list);
        }
        d.set("historia", historia);
        try {
            d.save(daneFile);
        } catch (IOException ex) {
            pl.getLogger().warning("Nie mozna zapisac dane.yml: " + ex.getMessage());
        }
    }

    // ---------- pakiety ----------

    public Pakiet get(String id) {
        return id == null ? null : pakiety.get(id.toLowerCase());
    }

    public Collection<Pakiet> wszystkie() {
        return pakiety.values();
    }

    public Pakiet utworz(String id, String nazwa) {
        Pakiet p = new Pakiet(id);
        p.nazwa = nazwa;
        pakiety.put(id, p);
        zapiszPakiety();
        return p;
    }

    public boolean usun(String id) {
        boolean r = pakiety.remove(id.toLowerCase()) != null;
        if (r) zapiszPakiety();
        return r;
    }

    // ---------- pakiety graczy ----------

    public List<Owned> lista(UUID u) {
        return gracze.computeIfAbsent(u, k -> new ArrayList<>());
    }

    public String data(long ms) {
        String f = pl.getConfig().getString("format-daty", "dd.MM.yyyy HH:mm");
        return DateTimeFormatter.ofPattern(f).withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(ms));
    }

    private void log(String t) {
        historia.add(data(System.currentTimeMillis()) + " | " + t);
        while (historia.size() > 500) historia.remove(0);
    }

    public List<String> historia(String filtr) {
        List<String> out = new ArrayList<>();
        for (int i = historia.size() - 1; i >= 0 && out.size() < 15; i--) {
            String h = historia.get(i);
            if (filtr == null || h.toLowerCase().contains(filtr.toLowerCase())) out.add(h);
        }
        return out;
    }

    public void daj(UUID u, String nazwaGracza, Pakiet pk, String od) {
        lista(u).add(new Owned(UUID.randomUUID().toString().substring(0, 8), pk.id, od, System.currentTimeMillis()));
        log(nazwaGracza + " <- " + pk.id + " (nadano, od: " + od + ")");
        zapiszDane();
        Player p = Bukkit.getPlayer(u);
        if (p != null) powiadom(p, pk, od);
    }

    public boolean przekaz(Player od, Player dla, Owned o) {
        Pakiet pk = get(o.pakiet());
        if (pk == null || !lista(od.getUniqueId()).remove(o)) return false;
        lista(dla.getUniqueId()).add(new Owned(UUID.randomUUID().toString().substring(0, 8), o.pakiet(), od.getName(), System.currentTimeMillis()));
        log(od.getName() + " -> " + dla.getName() + " : " + pk.id + " (przekazano)");
        zapiszDane();
        powiadomPrzekaz(dla, pk, od.getName());
        return true;
    }

    public void powiadom(Player p, Pakiet pk, String od) {
        pl.send(p, "otrzymano", "pakiet", pk.nazwa, "od", od);
        FileConfiguration c = pl.getConfig();
        if (c.getBoolean("powiadomienie.title.wlaczone", true)) {
            String g = c.getString("powiadomienie.title.glowny", "&a/%komenda%").replace("%komenda%", pl.komendaOdbierz());
            String s = c.getString("powiadomienie.title.pod", "").replace("%komenda%", pl.komendaOdbierz());
            p.showTitle(Title.title(Text.c(g), Text.c(s)));
        }
        String snd = c.getString("powiadomienie.dzwiek", "");
        if (!snd.isEmpty()) p.playSound(p.getLocation(), snd, 1f, 1f);
    }

    private void powiadomPrzekaz(Player p, Pakiet pk, String od) {
        pl.send(p, "otrzymano-przekaz", "pakiet", pk.nazwa, "od", od);
        String snd = pl.getConfig().getString("powiadomienie.dzwiek", "");
        if (!snd.isEmpty()) p.playSound(p.getLocation(), snd, 1f, 1f);
    }

    // ---------- odbieranie ----------

    private boolean maMiejsce(Player p, Pakiet pk) {
        Inventory tmp = Bukkit.createInventory(null, 36);
        ItemStack[] src = p.getInventory().getStorageContents();
        for (int i = 0; i < src.length && i < 36; i++) {
            if (src[i] != null) tmp.setItem(i, src[i].clone());
        }
        for (ItemStack it : pk.itemy) {
            if (!tmp.addItem(it.clone()).isEmpty()) return false;
        }
        return true;
    }

    public boolean odbierz(Player p, Owned o) {
        Pakiet pk = get(o.pakiet());
        if (pk == null) {
            pl.send(p, "pakiet-nie-istnieje", "id", o.pakiet());
            return false;
        }
        if (!maMiejsce(p, pk)) {
            pl.send(p, "brak-miejsca");
            return false;
        }
        if (!lista(p.getUniqueId()).remove(o)) return false;

        for (ItemStack it : pk.itemy) {
            for (ItemStack left : p.getInventory().addItem(it.clone()).values()) {
                p.getWorld().dropItem(p.getLocation(), left);
            }
        }
        for (String k : pk.komendy) wykonaj(k, p, pk, Map.of());
        FileConfiguration c = pl.getConfig();
        for (String r : pk.rangi) {
            String[] t = r.split(";", 2);
            if (t.length == 2) {
                wykonaj(c.getString("komendy-systemowe.ranga-czasowa", ""), p, pk, Map.of("ranga", t[0], "czas", t[1]));
            } else {
                wykonaj(c.getString("komendy-systemowe.ranga", ""), p, pk, Map.of("ranga", t[0]));
            }
        }
        for (Map.Entry<String, Integer> e : pk.klucze.entrySet()) {
            dajKlucz(p, e.getKey(), e.getValue());
        }
        log(p.getName() + " odebral " + pk.id);
        zapiszDane();
        pl.send(p, "odebrano", "pakiet", pk.nazwa);
        return true;
    }

    public void odbierzWszystko(Player p) {
        for (Owned o : new ArrayList<>(lista(p.getUniqueId()))) {
            if (!odbierz(p, o)) break;
        }
    }

    public void dajKlucz(Player p, String klucz, int ilosc) {
        Pakiet dummy = new Pakiet("-");
        wykonaj(pl.getConfig().getString("komendy-systemowe.klucz", ""), p, dummy,
                Map.of("klucz", klucz, "ilosc", String.valueOf(ilosc)));
    }

    private void wykonaj(String cmd, Player p, Pakiet pk, Map<String, String> extra) {
        if (cmd == null || cmd.isBlank()) return;
        String c = cmd.replace("%player%", p.getName())
                .replace("%uuid%", p.getUniqueId().toString())
                .replace("%pakiet%", pk.id);
        for (Map.Entry<String, String> e : extra.entrySet()) c = c.replace("%" + e.getKey() + "%", e.getValue());
        if (c.startsWith("/")) c = c.substring(1);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c);
    }
}
