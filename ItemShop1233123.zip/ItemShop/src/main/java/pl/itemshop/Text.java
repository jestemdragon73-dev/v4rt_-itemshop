package pl.itemshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.inventory.ItemStack;

public final class Text {
    private static final LegacyComponentSerializer LEG =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private Text() {}

    public static Component c(String s) {
        return LEG.deserialize(s == null ? "" : s).decoration(TextDecoration.ITALIC, false);
    }

    public static String nazwaItemu(ItemStack it) {
        if (it.hasItemMeta() && it.getItemMeta().hasDisplayName()) {
            return PlainTextComponentSerializer.plainText().serialize(it.getItemMeta().displayName());
        }
        return it.getType().name().toLowerCase().replace('_', ' ');
    }
}
