@echo off
chcp 65001 >nul
title ItemShop - instalator
setlocal EnableExtensions

echo ==========================================
echo   ItemShop - instalator
echo   Autor: v4rt_  ^|  Discord: dc.shulkermc.pl
echo ==========================================
echo.

rem ---- 1. szukanie jara ----
set "JAR="
for %%F in ("%~dp0ItemShop*.jar") do set "JAR=%%~fF"
if not defined JAR for %%F in ("%~dp0build\libs\ItemShop*.jar") do set "JAR=%%~fF"
if not defined JAR for %%F in ("%USERPROFILE%\Downloads\ItemShop*.jar") do set "JAR=%%~fF"
if not defined JAR for %%F in ("%USERPROFILE%\Desktop\ItemShop*.jar") do set "JAR=%%~fF"
if defined JAR goto checkjar

:askjar
echo Nie znaleziono pliku ItemShop.jar (ani tu, ani w Pobranych, ani na Pulpicie).
echo.
echo Masz 2 mozliwosci:
echo  1) wpisz nazwe repo na GitHubie, np.  v4rt/itemshop  - pobiore jara sam
echo     (repo musi byc publiczne, a build w Actions zielony)
echo  2) przeciagnij ItemShop.jar do tego okna i nacisnij Enter
echo.
echo Sam Enter = wyjscie.
set "JAR="
set /p "JAR=Repo lub plik jar: "
if not defined JAR goto nojar
set "JAR=%JAR:"=%"
if "%JAR:/=%"=="%JAR%" goto checkjar
if not "%JAR::=%"=="%JAR%" goto checkjar
if not "%JAR:\=%"=="%JAR%" goto checkjar
set "REPO=%JAR%"
goto download

:download
set "JAR=%~dp0ItemShop.jar"
echo.
echo Pobieram: https://github.com/%REPO%/releases/download/latest/ItemShop.jar
curl -L -f -o "%JAR%" "https://github.com/%REPO%/releases/download/latest/ItemShop.jar"
if errorlevel 1 goto dlfail
goto checkjar

:dlfail
if exist "%JAR%" del "%JAR%" >nul 2>&1
echo.
echo [BLAD] Nie udalo sie pobrac. Sprawdz, czy:
echo  - nazwa repo jest poprawna (uzytkownik/repo) i repo jest publiczne,
echo  - w Actions build zakonczyl sie na zielono (powstaje wtedy Release "latest").
echo.
set "JAR="
goto askjar

:checkjar
set "JAR=%JAR:"=%"
set "EXT="
for %%A in ("%JAR%") do set "EXT=%%~xA"
if /i not "%EXT%"==".jar" goto badjar
if not exist "%JAR%" goto badjar
if exist "%JAR%\" goto badjar
echo Plik: %JAR%
echo.
goto findplugins

:badjar
echo.
echo [BLAD] To nie jest poprawny plik .jar: %JAR%
echo.
goto askjar

:nojar
echo.
echo Brak pliku ItemShop.jar - nie ma co instalowac.
echo Zbuduj go na GitHubie, pobierz i uruchom ten plik ponownie.
echo.
pause
exit /b 1

rem ---- 2. szukanie folderu plugins ----
:findplugins
set "CFG=%~dp0sciezka_serwera.txt"
set "PLUGINS="
if exist "%CFG%" set /p PLUGINS=<"%CFG%"
if not defined PLUGINS if exist "%~dp0plugins\" set "PLUGINS=%~dp0plugins"
if not defined PLUGINS if exist "%~dp0..\plugins\" set "PLUGINS=%~dp0..\plugins"
if defined PLUGINS goto checkplugins

:askplugins
echo Podaj sciezke do folderu serwera lub do folderu plugins
echo Przyklad: C:\serwer   lub   C:\serwer\plugins
echo (sam Enter = wyjscie)
set "PLUGINS="
set /p "PLUGINS=Sciezka: "
if not defined PLUGINS exit /b 1

:checkplugins
set "PLUGINS=%PLUGINS:"=%"
if exist "%PLUGINS%\plugins\" set "PLUGINS=%PLUGINS%\plugins"
if not exist "%PLUGINS%\" goto badplugins
goto copyjar

:badplugins
echo.
echo [BLAD] Taki folder nie istnieje: %PLUGINS%
echo.
goto askplugins

rem ---- 3. kopiowanie ----
:copyjar
copy /Y "%JAR%" "%PLUGINS%\ItemShop.jar" >nul
if errorlevel 1 goto copyfail

>"%CFG%" echo(%PLUGINS%

echo.
echo [OK] Zainstalowano: %PLUGINS%\ItemShop.jar
echo Zrestartuj serwer, a potem edytuj plugins\ItemShop\config.yml
echo Sciezka zapisana - nastepnym razem nie bedzie pytac o folder.
echo.
pause
exit /b 0

:copyfail
echo.
echo [BLAD] Nie udalo sie skopiowac pliku. Wylacz serwer i sprobuj ponownie.
echo.
pause
exit /b 1
